<#assign licenseFirst = "/*">
<#assign licensePrefix = " * ">
<#assign licenseLast = " */">
<#include "${project.licensePath}">

<#if package?? && package != "">
package ${package};

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

</#if>
/**
 *
 * @author ${user}
 */
public class ${name} {

    private static final Logger logger = LoggerFactory.getLogger(${name}.class);

}
